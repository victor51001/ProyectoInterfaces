﻿INSERT INTO Puestos (nombre) VALUES
('Administrador'),
('Administrativo'),
('Agente'),
('Jefe'),
('nulo');
