﻿CREATE TABLE Cliente (
    dni VARCHAR(255) PRIMARY KEY,
    nombre VARCHAR(255),
    apellidos VARCHAR(255),
    telefono INT,
    email VARCHAR(255)
);