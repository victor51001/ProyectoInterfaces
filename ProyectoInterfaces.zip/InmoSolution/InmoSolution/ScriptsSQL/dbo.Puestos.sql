﻿CREATE TABLE [dbo].[Puestos] (
    [id]     INT           NOT NULL IDENTITY,
    [nombre] VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);

